
<!--
		NOT SCRIPT FILE
		file <- "20_pandoc_output_tex_file_DEBUG.md"

		PURPOSE:  simple .md file, show as .tex, using PANDOC
							DEBUG !


		USAGE:
!pandoc % -f markdown -t latex -o DEBUG.tex

		Rmk:  ^I  = <TAB>
-->

####	HELLO	
